"""Accidental-use guard against the actual controller, not an OS sandbox."""
import json,os,re,socket,subprocess
from pathlib import Path
def allocation(root):
    root=Path(root).resolve();expected=Path('/XYFS02/HDD_POOL/sysu_pww/sysu_pww_2/dsh-simulation/runs')
    assert root.parent==expected and re.fullmatch(r'[a-z0-9][a-z0-9_-]{0,63}',root.name)
    assert os.getuid()==15505 and root.stat().st_uid==15505
    job=os.environ.get('SLURM_JOB_ID','');assert re.fullmatch(r'[0-9]+',job),'No scheduler allocation'
    text=subprocess.check_output(['/usr/bin/scontrol','show','job','-o',job],universal_newlines=True)
    row=dict(re.findall(r'(\w+)=([^\s]+)',text))
    assert row.get('JobState')=='RUNNING' and re.fullmatch(r'(?:sysu_pww_2|15505)\(15505\)',row.get('UserId','')),row
    assert row.get('JobId')==job and row.get('Account')=='sysu_pww',row
    assert int(row['NumNodes'])==1 and int(row['NumCPUs'])>=64
    nodes=subprocess.check_output(['/usr/bin/scontrol','show','hostnames',row['NodeList']],universal_newlines=True).split()
    host=socket.gethostname().split('.')[0]
    assert host in [n.split('.')[0] for n in nodes] and host.startswith('cnode')
    assert not host.startswith('ln')
    cpus=sorted(os.sched_getaffinity(0));assert len(cpus)>=64
    return {'job_id':job,'hostname':host,'uid':os.getuid(),'allocated_nodes':nodes,'controller_job':row,'CPU_affinity':cpus,'raw_controller_job':text}
