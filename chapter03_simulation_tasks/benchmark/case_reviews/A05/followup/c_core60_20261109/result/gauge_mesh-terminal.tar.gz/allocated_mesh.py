"""Derive the Denny mesh variant and stage the previously verified C runtime."""
import hashlib
import importlib.util
import json
import math
import os
import shutil
import tarfile
from pathlib import Path, PurePosixPath

from allocated_guard import allocation


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def stage_runtime(root, plan):
    previous = Path(plan['runtime_archive'])
    assert previous == Path('/XYFS01/sysu_pww_2/dsh-simulation/runs/ch3-c-full-20261107t024443z/payload.tar.gz') and previous.parent != root
    assert previous.is_file() and not previous.is_symlink()
    assert previous.parent.resolve() == previous.parent and previous.stat().st_uid == os.getuid()
    assert sha(previous) == plan['runtime_archive_sha256']
    with tarfile.open(previous) as archive:
        manifest = json.load(archive.extractfile('payload_manifest.json'))
        expected = {row['path']: row for row in manifest['files'] if row['path'].startswith('runtime/')}
        seen = set()
        for member in archive:
            if not member.name.startswith('runtime/'):
                continue
            path = PurePosixPath(member.name)
            assert member.isfile() and not path.is_absolute() and '..' not in path.parts
            assert member.name not in seen
            seen.add(member.name)
            target = root / member.name
            target.parent.mkdir(parents=True, exist_ok=True)
            assert root in target.resolve().parents
            with target.open('xb') as sink, archive.extractfile(member) as source:
                shutil.copyfileobj(source, sink)
            assert sha(target) == expected[member.name]['sha256']
            os.chmod(target, member.mode & 0o700 or 0o600)
        assert seen == set(expected)


