#!/bin/bash
# MSB450 S05 one 60 mm core refinement; submit through yhbatch.
set -euo pipefail
umask 077
unset LD_LIBRARY_PATH LD_PRELOAD PYTHONPATH PYTHONHOME
export PYTHONNOUSERSITE=1
run_dir=/XYFS02/HDD_POOL/sysu_pww/sysu_pww_2/dsh-simulation/runs/ch3-c-s05-core60-limited-20261109
[[ $(pwd -P) == "$run_dir" ]]
[[ -n ${SLURM_JOB_ID:-} && -n ${SLURM_JOB_NODELIST:-} ]]
/usr/bin/python3 - "$run_dir" <<'PY'
import hashlib,json,os,re,socket,subprocess,sys,tarfile
from pathlib import Path,PurePosixPath
root=Path(sys.argv[1]).resolve()
assert root.parent==Path('/XYFS02/HDD_POOL/sysu_pww/sysu_pww_2/dsh-simulation/runs') and root.stat().st_uid==os.getuid()==15505
job=os.environ['SLURM_JOB_ID'];assert re.fullmatch(r'[0-9]+',job)
text=subprocess.check_output(['/usr/bin/scontrol','show','job','-o',job],universal_newlines=True)
row=dict(re.findall(r'(\w+)=([^\s]+)',text))
with (root/'bootstrap_allocation.json').open('x') as f:json.dump({'controller':row,'raw_controller':text,'uid':os.getuid(),'hostname':socket.gethostname()},f)
assert row['JobState']=='RUNNING' and re.fullmatch(r'(?:sysu_pww_2|15505)\(15505\)',row.get('UserId','')),row
assert row.get('JobId')==job and row.get('Account')=='sysu_pww',row
assert row['WorkDir']==str(root) and row['JobName']==root.name and row['Partition']=='deimos',row
nodes=subprocess.check_output(['/usr/bin/scontrol','show','hostnames',row['NodeList']],universal_newlines=True).split()
host=socket.gethostname().split('.')[0];assert host.startswith('cnode') and host in [n.split('.')[0] for n in nodes]

def require(condition, message):
    if not condition:
        raise RuntimeError(message)
def quota_headroom(raw, workspace):
    # lfs wraps the counters to the next line when the mount path is long.
    lines = iter(raw.splitlines())
    for line in lines:
        if line.split()[:1] != [workspace]:
            continue
        counters = line.split()[1:] or next(lines, "").split()
        require(len(counters) >= 3, "group quota counters missing")
        used, soft, hard = (int(value.rstrip("*")) for value in counters[:3])
        require(0 < soft <= hard and used >= 0, "unexpected group quota limits")
        return soft - used
    raise RuntimeError("group quota path missing")

workspace=str(root.parent.parent)
quota=subprocess.check_output(['/usr/bin/lfs','quota','-g','11452',workspace],universal_newlines=True)
headroom=quota_headroom(quota,workspace)
require(headroom >= 8388608,'Insufficient group soft quota')
with (root/'allocated_quota.json').open('x') as f:json.dump({'workspace':workspace,'soft_quota_headroom_KiB':headroom},f)
archive=root/'payload.tar.gz';assert hashlib.sha256(archive.read_bytes()).hexdigest()=='83fbccc6c8e3c555d2520bc10235e516a7daab7678dd6e27c2a99a54df0ba068'
with (root/'extraction_started.json').open('x') as f:json.dump({'job_id':job,'node':host},f)
with tarfile.open(archive) as t:
    items=t.getmembers();names=[m.name for m in items];assert len(set(names))==len(names)
    manifest=json.load(t.extractfile('payload_manifest.json'));expected={r['path']:r for r in manifest['files']}
    assert set(names)==set(expected)|{'payload_manifest.json'}
    for m in items:
        name=PurePosixPath(m.name);assert m.isfile() and not name.is_absolute() and '..' not in name.parts
        dest=root/m.name;dest.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
        assert os.path.commonpath([str(root),str(dest.resolve())])==str(root)
        data=t.extractfile(m).read()
        if m.name in expected:assert hashlib.sha256(data).hexdigest()==expected[m.name]['sha256']
        with dest.open('xb') as f:f.write(data)
        os.chmod(dest,m.mode&0o700 or 0o600)
PY
mkdir -p "$run_dir/tmp/home"
/usr/bin/python3 "$run_dir/derive_gauge_mesh.py"
source "$run_dir/native-env.sh"
exec /usr/bin/python3 "$run_dir/run_full_windows.py"
