"""Change only the conformal block subdivisions serving the A05 gauges."""
import hashlib
import json
import math
import re
import shutil
from pathlib import Path

from allocated_guard import allocation
from allocated_mesh import sha, stage_runtime


def derive(root, plan):
    seed = root / 'seed'
    spec_path = seed / 'specification.json'
    assert sha(spec_path) == plan['parent_spec_sha256']
    frozen = json.loads(spec_path.read_bytes())
    for group, base in [('input_files', seed / 'case'), ('package_code', seed), ('source_files', seed)]:
        for row in frozen[group]:
            assert sha(base / row['path']) == row['sha256'], row['path']
    binding = root / 'autodyn_reference.json'
    assert sha(binding) == plan['autodyn_binding_sha256']
    references = json.loads(binding.read_bytes())['autodyn_peak_kPa_by_sensor']
    assert set(references) == set(frozen['comparison']['required_sensors']) and len(references) == 25
    assert all(value > 0 for value in references.values())

    config = plan['cases']['gauge_mesh']
    dest = root / 'cases/gauge_mesh'
    shutil.copytree(seed, dest)
    mesh_name = 'system/blockMeshDict'
    original = (seed / 'case' / mesh_name).read_bytes()
    text = original.decode('ascii')
    eol = '\r\n' if b'\r\n' in original else '\n'
    vertices_text, blocks_text = text.split(f');{eol}blocks ({eol}', 1)
    blocks_text, tail = blocks_text.split(f');{eol}edges', 1)
    vertex_lines = vertices_text.split(f'vertices ({eol}', 1)[1].splitlines()
    vertices = [tuple(map(float, line.strip('()').split())) for line in vertex_lines]
    assert len(vertices) == 1690 and all(len(vertex) == 3 for vertex in vertices)

    mesh = frozen['mesh']
    horizontal_limit = config['refinement_horizontal_abs_limit_m']
    z_limit = config['refinement_height_m']
    target = config['refined_target_spacing_m']
    rebuilt = []
    old_cells = 0
    new_cells = 0
    changed = 0
    for line in blocks_text.splitlines():
        if not line.strip():
            continue
        match = re.fullmatch(r'hex \(([\d ]+)\) \(([\d ]+)\) simpleGrading \(1 1 1\)', line)
        assert match, line
        ids = [int(x) for x in match[1].split()]
        old = [int(x) for x in match[2].split()]
        low, high = vertices[ids[0]], vertices[ids[6]]
        new = old.copy()
        for axis in range(3):
            midpoint = (low[axis] + high[axis]) / 2
            source_strip = abs(midpoint) < .121 if axis < 2 else .079 < midpoint < .321
            gauge_strip = abs(midpoint) < horizontal_limit if axis < 2 else 0 <= midpoint < z_limit
            if gauge_strip and not source_strip:
                assert high[axis] > low[axis]
                new[axis] = max(old[axis], math.ceil(round((high[axis] - low[axis]) / target, 10)))
        if new != old:
            line = line[:match.start(2)] + ' '.join(map(str, new)) + line[match.end(2):]
            changed += 1
        old_cells += math.prod(old)
        new_cells += math.prod(new)
        rebuilt.append(line)

    assert old_cells == mesh['cells'] == 2949304 and len(rebuilt) == mesh['blocks'] == 1268
    assert changed > 0 and new_cells == 3744880
    updated = (vertices_text + f');{eol}blocks ({eol}' + eol.join(rebuilt) + eol + f');{eol}edges' + tail).encode('ascii')
    mesh_file = dest / 'case' / mesh_name
    mesh_file.write_bytes(updated)
    frozen['mesh'] = dict(mesh, cells=new_cells, gauge_region_spacing_target_m=target,
                          refined_axis_strips={'horizontal_midpoint_abs_lt_m': horizontal_limit, 'vertical_midpoint_below_m': z_limit},
                          changed_block_subdivisions=changed, source_axis_strips_preserved=True)
    changed_input = []
    for row in frozen['input_files']:
        actual = sha(dest / 'case' / row['path'])
        if actual != row['sha256']:
            changed_input.append(row['path'])
            row['sha256'] = actual
    assert changed_input == [mesh_name]
    frozen['input_manifest_sha256'] = hashlib.sha256(json.dumps(frozen['input_files'], sort_keys=True).encode()).hexdigest()
    frozen['case_id'] = plan['case_id']
    destination_spec = dest / 'specification.json'
    destination_spec.write_text(json.dumps(frozen, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
    receipt = {'parent_spec_sha256': plan['parent_spec_sha256'], 'refined_spec_sha256': sha(destination_spec),
               'changed_input_dictionaries': changed_input, 'original_cells': old_cells, 'refined_cells': new_cells,
               'changed_blocks': changed, 'source_fraction_dictionary_byte_equal': True,
               'fixed_probe_dictionary_byte_equal': True, 'block_vertices_and_boundary_faces_byte_equal': True}
    (root / 'mesh_derivation.json').write_text(json.dumps(receipt, indent=2) + '\n')


if __name__ == '__main__':
    run_root = Path(__file__).resolve().parent
    allocation(run_root)
    run_plan = json.loads((run_root / 'plan.json').read_bytes())
    stage_runtime(run_root, run_plan)
    derive(run_root, run_plan)
