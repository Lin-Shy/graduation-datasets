#!/bin/bash
# Reviewed relocation only; no shared installation or native binary changes.
task_runtime_root="/XYFS02/HDD_POOL/sysu_pww/sysu_pww_2/dsh-simulation/runs/ch3-c-s05-core60-limited-20261109/runtime"
export HOME="/XYFS02/HDD_POOL/sysu_pww/sysu_pww_2/dsh-simulation/runs/ch3-c-s05-core60-limited-20261109/tmp/home" TMPDIR="/XYFS02/HDD_POOL/sysu_pww/sysu_pww_2/dsh-simulation/runs/ch3-c-s05-core60-limited-20261109/tmp"
export PYTHONPYCACHEPREFIX="/XYFS02/HDD_POOL/sysu_pww/sysu_pww_2/dsh-simulation/runs/ch3-c-s05-core60-limited-20261109/tmp/pycache"
export USER=sysu_pww_2 LOGNAME=sysu_pww_2
export WM_PROJECT=OpenFOAM WM_PROJECT_VERSION=9 WM_OPTIONS=linux64GccDPInt32Opt
export WM_PRECISION_OPTION=DP WM_LABEL_SIZE=32 WM_COMPILE_OPTION=Opt WM_COMPILER=Gcc WM_ARCH_OPTION=64
export WM_PROJECT_INST_DIR="$task_runtime_root/data/OpenFOAM"
export WM_PROJECT_DIR="$WM_PROJECT_INST_DIR/OpenFOAM-9"
export WM_THIRD_PARTY_DIR="$WM_PROJECT_INST_DIR/ThirdParty-9"
export WM_PROJECT_USER_DIR="$HOME/OpenFOAM/sysu_pww_2-9"
export BLAST_DIR="$WM_PROJECT_INST_DIR/blastfoam"
export FOAM_ETC="$WM_PROJECT_DIR/etc"
export FOAM_LIBBIN="$WM_PROJECT_DIR/platforms/$WM_OPTIONS/lib"
export FOAM_APPBIN="$WM_PROJECT_DIR/platforms/$WM_OPTIONS/bin"
export FOAM_USER_LIBBIN="$BLAST_DIR/lib" FOAM_USER_APPBIN="$BLAST_DIR/bin"
export FOAM_MPI=openmpi-system WM_MPLIB=SYSTEMOPENMPI
export MPI_ARCH_PATH="$task_runtime_root/usr/lib64/openmpi" OPAL_PREFIX="$task_runtime_root/usr/lib64/openmpi"
export PMIX_MCA_mca_base_component_path="$task_runtime_root/usr/lib64/pmix"
export OMPI_MCA_mca_base_component_path="$MPI_ARCH_PATH/lib/openmpi"
export OMPI_MCA_btl=self,vader,tcp OMPI_MCA_pml=ob1 OMPI_MCA_plm=isolated OMPI_MCA_ras='^slurm'
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export PATH="$BLAST_DIR/bin:$FOAM_APPBIN:$MPI_ARCH_PATH/bin:/usr/bin:/bin"
export LD_LIBRARY_PATH="$task_runtime_root/data/chapter3-native-runtime/system-libs:$MPI_ARCH_PATH/lib:$FOAM_LIBBIN/openmpi-system:$FOAM_LIBBIN:$WM_THIRD_PARTY_DIR/platforms/linux64GccDPInt32/lib/openmpi-system:$WM_THIRD_PARTY_DIR/platforms/linux64GccDPInt32/lib:$BLAST_DIR/lib:$FOAM_LIBBIN/dummy"
export CH3_THERMO_PRELOAD="$task_runtime_root/data/chapter3-native-runtime/thermo-cache/libphaseFluid_basic_const_eConst_JWL_specie______4578ed329e0d1256b0b8b8129f9d4093e76746a8.so"
unset LD_PRELOAD OMPI_MCA_mca_base_env_list
