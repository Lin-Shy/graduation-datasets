"""A05 gauge-region fixed-window comparison on the C cluster.

Executed only inside the scheduler batch allocation with allocated_guard.py.
This is neither an autonomous script interface nor a formal DSH experiment.
"""
import argparse
import concurrent.futures
import hashlib
import json
import math
import os
import re
import shutil
import signal
import subprocess
import sys
import tarfile
import time
from pathlib import Path

from allocated_guard import allocation
from score_autodyn import evaluate as score_autodyn


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def save(path, data):
    temporary = path.with_name(path.name + '.part')
    temporary.write_text(json.dumps(data, indent=2) + '\n')
    temporary.replace(path)


def health(text):
    temperatures = [float(v) for v in re.findall(r'min\(T\):\s*([-+\deE.]+)', text)]
    if any(not math.isfinite(v) or v <= 0 for v in temperatures):
        return 'nonpositive_or_nonfinite_temperature_native_log'
    if 'FOAM FATAL IO ERROR' in text:
        return 'input_dictionary_error'
    if re.search(r'FOAM FATAL|\bnan\b|^\s*(?:\[\d+\]\s*)?Floating point exception(?:\s|$)', text, re.I | re.M):
        return 'fatal_native_log'
    return None


def archive_case(root, key, package, record):
    """Hash and archive stable terminal files on the allocated compute node."""
    case = package / 'run-case'
    retained = {'postProcessing', 'system'}
    paths = [path for path in package.rglob('*')
             if case not in path.parents or path.relative_to(case).parts[0] in retained]
    raw_location = package / 'raw_fields_retention.json'
    save(raw_location, {'remote_case': str(case), 'local_archive_includes_pressure_histories': True,
                        'remote_case_includes_written_native_fields_and_mesh': True})
    paths.append(raw_location)
    paths += [root / name for name in ['plan.json', 'payload_manifest.json', 'bootstrap_allocation.json',
                                      'allocation.json', 'native-env.sh', 'allocated_guard.py',
                                      'run_full_windows.py', 'batch.sh', 'mesh_derivation.json', 'derive_gauge_mesh.py', 'allocated_mesh.py', 'allocated_quota.json', 'refinement_binding.json', 'autodyn_reference.json', 'score_autodyn.py', 'material_binding.json', 'apply_m46.py', 'conservative_source.py']]
    members = []
    for path in sorted(paths):
        assert not path.is_symlink(), str(path)
        if path.is_file():
            members.append({'path': str(path.relative_to(root)), 'bytes': path.stat().st_size, 'sha256': digest(path)})
    manifest = root / (key + '-evidence-manifest.json')
    save(manifest, {'case_key': key, 'terminal_run_completed': record['completed'], 'files': members})
    target = root / (key + '-evidence.tar.gz')
    assert not target.exists()
    with tarfile.open(str(target) + '.part', 'w:gz', compresslevel=2) as archive:
        for row in members:
            archive.add(root / row['path'], arcname=row['path'], recursive=False)
        archive.add(manifest, arcname=manifest.name, recursive=False)
    Path(str(target) + '.part').replace(target)
    save(root / (key + '-archive_receipt.json'), {
        'case_key': key, 'created_at_epoch': time.time(), 'path': target.name,
        'bytes': target.stat().st_size, 'sha256': digest(target),
        'manifest_sha256': digest(manifest), 'completed': record['completed'],
        'health_failure': record['health_failure'], 'actual_APE_MAPE_only_if_complete': True,
        'model_match_approved': False, 'Gold_approved': False,
    })


def case_attempt(root, key, cfg, context):
    os.sched_setaffinity(0, cfg['CPU_affinity'])
    package = root / 'cases' / key
    spec = json.loads((package / 'specification.json').read_text())
    derivation = json.loads((root / 'mesh_derivation.json').read_text())
    spec_hash = derivation['refined_spec_sha256']
    assert digest(package / 'specification.json') == spec_hash
    assert len(spec['comparison']['required_sensors']) == 25
    assert len(spec['comparison']['reference_rows']) == 24
    assert spec['comparison']['window_s'] == cfg['physical_window_s']
    for group, base in [('input_files', package / 'case'), ('package_code', package), ('source_files', package)]:
        for row in spec[group]:
            assert digest(base / row['path']) == row['sha256'], row['path']
    assert shutil.disk_usage(package).free > 8 * 1024 ** 3
    case = package / 'run-case'
    assert not case.exists() and not (package / 'run.json').exists(), 'Existing attempt refused'
    shutil.copytree(package / 'case', case)
    dd = case / 'system/decomposeParDict'
    old = dd.read_bytes()
    new, count = re.subn(r'\bnumberOfSubdomains\s+\d+;', 'numberOfSubdomains ' + str(cfg['MPI_ranks']) + ';', old.decode())
    assert count == 1
    assert 'method scotch;' in new and cfg['MPI_ranks'] == 48
    dd.write_text(new)
    record = {
        'case_id': spec['case_id'], 'case_key': key, 'pid': os.getpid(), 'uid': os.getuid(),
        'started_at': time.time(), 'allocation': context, 'actual_CPU_affinity': sorted(os.sched_getaffinity(0)),
        'execution_extension': cfg, 'specification_sha256': digest(package / 'specification.json'),
        'actual_runner_sha256': digest(Path(__file__)), 'completed': False, 'health_failure': None,
        'commands': [], 'formal_DSH_score_or_Gold': False, 'pristine_start_time_s': 0,
        'decomposition_execution_only': {'old_sha256': hashlib.sha256(old).hexdigest(), 'new_sha256': digest(dd)},
    }
    receipt = package / 'run.json'
    save(receipt, record)
    deadline = time.monotonic() + cfg['wall_budget_s']
    initialize = [['setFields'], ['postProcess', '-func', 'writeCellVolumes', '-time', '0']]
    initialize += [[sys.executable, str(package / cfg['initializer']), '--package', str(package), '--case', str(case)]]
    mpi = ['mpirun', '--host', context['hostname'] + ':' + str(cfg['MPI_ranks']), '-np', str(cfg['MPI_ranks']), '--bind-to', 'none']
    solver = mpi + ['-x', 'LD_PRELOAD=' + os.environ['CH3_THERMO_PRELOAD'], 'blastFoam', '-parallel']
    plans = [['blockMesh'], *initialize, ['checkMesh'], ['decomposePar'], solver]
    child = None
    try:
        for i, argv in enumerate(plans):
            is_solver = argv == solver
            log = package / (str(i) + '-' + ('blastFoam' if is_solver else Path(argv[0]).name) + '.log')
            item = {'argv': argv, 'started_at': time.time(), 'log': log.name}
            record['commands'].append(item)
            save(receipt, record)
            with log.open('wb') as stream:
                child = subprocess.Popen(argv, cwd=case, stdin=subprocess.DEVNULL, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
                item['process_group_leader_PID'] = child.pid
                save(receipt, record)
                offset = 0
                previous = ''
                while child.poll() is None:
                    time.sleep(1)
                    with log.open('rb') as reader:
                        reader.seek(offset)
                        addition = reader.read().decode(errors='replace')
                        offset = reader.tell()
                    scan = previous + addition
                    previous = scan[-20000:]
                    times = re.findall(r'^Time = ([-+\deE.]+)', scan, re.M)
                    if times:
                        record['observed_time_s'] = float(times[-1])
                    if is_solver:
                        record['health_failure'] = health(scan)
                    if shutil.disk_usage(package).free < 2 * 1024 ** 3:
                        record['stop_reason'] = 'disk_reserve'
                    if time.monotonic() > deadline:
                        record['stop_reason'] = 'wall_budget'
                    if record['health_failure'] or record.get('stop_reason'):
                        if child.poll() is None:
                            os.killpg(child.pid, signal.SIGTERM)
                        break
                    if times:
                        save(receipt, record)
                try:
                    code = child.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
                    code = child.wait()
            text = log.read_text(errors='replace')
            item.update(exit_code=code, finished_at=time.time(), sha256=digest(log))
            if is_solver:
                record['health_failure'] = health(text) or record['health_failure']
            save(receipt, record)
            if code or record['health_failure'] or record.get('stop_reason'):
                break
            if argv == ['checkMesh'] and 'Mesh OK' not in text:
                record['stop_reason'] = 'mesh_not_OK'
                break
        else:
            times = [float(v) for v in re.findall(r'^Time = ([-+\deE.]+)', text, re.M)]
            record['completed'] = bool(re.search(r'^End\s*$', text, re.M)) and bool(times) and max(times) >= cfg['physical_window_s'][1] - 1e-10 and not record['health_failure']
    except BaseException as error:
        record['exception'] = {'type': type(error).__name__, 'message': str(error)}
        if child is not None and child.poll() is None:
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=20)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
    finally:
        record['finished_at'] = time.time()
        save(receipt, record)
        record['fixed_scorer_exit_code'] = None
        record['task_completion_pass'] = False
        if record['completed']:
            with (package / 'fixed-scoring.log').open('wb') as stream:
                result = subprocess.run([sys.executable, str(package / 'score_reference_supplement.py'),
                                         '--package', str(package), '--case', str(case)],
                                        stdout=stream, stderr=subprocess.STDOUT, timeout=600)
            record['fixed_scorer_exit_code'] = result.returncode
            if result.returncode == 0:
                scored = json.loads((package / 'diagnostics/peak_comparison.json').read_text())
                if scored['status'] == 'complete_conditional_pressure_diagnostic':
                    score_autodyn(root / 'autodyn_reference.json', package)
                    record['task_completion_pass'] = True
        save(receipt, record)
        archive_case(root, key, package, record)
    return {'case_key': key, 'completed': record['completed'], 'health_failure': record['health_failure'], 'fixed_scorer_exit_code': record['fixed_scorer_exit_code'], 'task_completion_pass': record['task_completion_pass']}


def main():
    root = Path(__file__).resolve().parent
    context = allocation(root)
    plan = json.loads((root / 'plan.json').read_bytes())
    assert plan['role'] == 'a05_m46_core_60mm_limited' and set(plan['cases']) == {'gauge_mesh'}
    assert digest(root / 'runtime/data/OpenFOAM/blastfoam/bin/blastFoam') == plan['native_engine_sha256']
    assert digest(Path(os.environ['CH3_THERMO_PRELOAD'])) == plan['native_thermo_preload_sha256']
    assert digest(root / 'autodyn_reference.json') == plan['autodyn_binding_sha256']
    cfg = plan['cases']['gauge_mesh']
    cfg['CPU_affinity'] = context['CPU_affinity'][-48:]
    assert len(context['CPU_affinity']) == 64 and len(cfg['CPU_affinity']) == 48
    assert set(cfg['CPU_affinity']) <= set(context['CPU_affinity'])
    save(root / 'allocation.json', context)
    result = case_attempt(root, 'gauge_mesh', cfg, context)
    save(root / 'full_windows_receipt.json', {'allocation': context, 'result': result, 'finished_at': time.time()})
    return 0 if result['task_completion_pass'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
