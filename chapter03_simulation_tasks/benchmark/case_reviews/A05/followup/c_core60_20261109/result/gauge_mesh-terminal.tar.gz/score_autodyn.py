"""Compare the full fixed A05 gauge set against published AUTODYN peaks."""
import json
import math
from pathlib import Path


def evaluate(binding, package):
    report = json.loads((package / 'diagnostics/peak_comparison.json').read_bytes())
    assert report['status'] == 'complete_conditional_pressure_diagnostic' and report['full_window_all_sensors']
    refs = json.loads(binding.read_bytes())['autodyn_peak_kPa_by_sensor']
    predictions = report['predictions']
    assert predictions.keys() == refs.keys() and len(refs) == 25 and report['fixed_APE_denominator'] == 24
    rows = []
    for sensor, reference in refs.items():
        peak = predictions[sensor]['full_peak_Pa'] / 1000
        assert math.isfinite(peak) and reference > 0
        rows.append({'sensor': sensor, 'reference_kPa': reference, 'simulation_kPa': peak,
                     'APE_percent': 100 * abs(peak - reference) / reference})
    (package / 'diagnostics/autodyn_comparison.json').write_text(json.dumps({
        'reference': 'MSB450 Table B.2 shot 10 location 4 AUTODYN P+',
        'reference_count': len(rows), 'window_s': [0, .05],
        'MAPE_percent': math.fsum(row['APE_percent'] for row in rows) / len(rows),
        'rows': rows,
    }, indent=2) + '\n')
