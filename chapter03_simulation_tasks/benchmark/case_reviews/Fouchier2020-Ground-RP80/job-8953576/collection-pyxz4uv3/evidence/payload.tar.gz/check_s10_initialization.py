"""Validate native 0/ fields after setFields and writeCellVolumes, before solving."""

import json
import math
from pathlib import Path
import sys

from foam_fields import read_field, read_internal_volume_scalar


def check(case):
    binding = json.loads((case.parent / "staging_receipt.json").read_text(encoding="utf-8"))
    initial = case / "0"
    layout = {"byte_order": "little", "scalar_bits": 64, "label_bits": 32}
    vfile = initial / "V"
    with vfile.open("rb") as source:
        internal_only = b"volScalarField::Internal" in source.read(1500)
    reader = read_internal_volume_scalar if internal_only else read_field
    volumes = reader(vfile, layout)["internal"]
    pressure, rho, temperature = [read_field(initial / name, layout)["internal"] for name in ("p", "rho", "T")]
    n = binding["geometry"]["planned_cells"]
    assert len(volumes) == len(pressure) == len(rho) == len(temperature) == n
    spec = binding["source_check"]
    selected = []
    for index, (p, density, temp, vol) in enumerate(zip(pressure, rho, temperature, volumes)):
        assert all(math.isfinite(v) and v > 0 for v in (p, density, temp, vol)), index
        assert math.isclose(density * spec["gas_constant_J_kg_K"] * temp, p, rel_tol=1e-7), index
        if math.isclose(p, spec["selected_cell_pressure_absolute_Pa"], rel_tol=1e-9):
            selected.append(vol)
        else:
            assert math.isclose(p, spec["ambient_pressure_absolute_Pa"], rel_tol=1e-9), index
    observed = math.fsum(selected)
    relative = (observed / spec["target_wedge_volume_m3"]) - 1
    assert selected and abs(relative) <= spec["max_relative_volume_error"]
    result = {
        "cell_count": n,
        "source_cell_count": len(selected),
        "observed_wedge_source_volume_m3": observed,
        "relative_source_volume_error": relative,
        "eos_consistent_at_all_cell_centres": True,
    }
    with (case.parent / "native_initialization_receipt.json").open("x", encoding="utf-8") as dest:
        json.dump(result, dest, indent=2)


if __name__ == "__main__":
    check(Path(sys.argv[1]).resolve())
