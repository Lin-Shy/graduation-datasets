"""Score the fixed S10 wall-pressure peaks from a collected C-cluster run."""

import argparse
from hashlib import sha256
import json
import math
from pathlib import Path
import re
from statistics import fmean


REFERENCE_GROUPS = ("experiment", "published_OpenFOAM")
PROBE_HEADER = re.compile(r"#\s*Probe\s+(\d+)\s+\(([^()]*)\)")
HEALTH_LINE = re.compile(r"max\(([pT])\):\s*(\S+),\s*min\(\1\):\s*(\S+)")


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def file_digest(path):
    digest = sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def check_native_run(folder, receipt_path, binding, samples, probe_digest):
    run_path = folder / "run.json"
    run = read_json(run_path)
    allocation = run["allocation"]
    require(str(allocation["job_id"]).isdigit() and allocation["hostname"] in allocation["allocated_nodes"],
            "missing scheduler allocation evidence")
    require(run["staging_receipt_sha256"] == file_digest(receipt_path), "run did not bind this staged revision")
    require(run["native_probe_sha256"] == probe_digest, "native probe hash mismatch")
    require(run["completed"] is True and run["health_failure"] is None, "native run incomplete or unhealthy")
    steps = run["commands"]
    expected = binding["compute_node_preflight"] + [binding["post_preflight_solver"]]
    require([step["argv"] for step in steps] == expected and all(step["exit_code"] == 0 for step in steps),
            "required native command failed or is missing")
    log_path = folder / steps[-1]["log"]
    log_digest = file_digest(log_path)
    require(log_digest == steps[-1]["sha256"], "solver log hash mismatch")
    initial_path = folder / "native_initialization_receipt.json"
    initial_digest = file_digest(initial_path)
    require(run["native_initialization_receipt_sha256"] == initial_digest, "native initialization hash mismatch")
    initial = read_json(initial_path)
    require(initial["cell_count"] == binding["geometry"]["planned_cells"]
            and 0 < initial["source_cell_count"] < initial["cell_count"]
            and initial["eos_consistent_at_all_cell_centres"] is True
            and abs(initial["relative_source_volume_error"]) <= binding["source_check"]["max_relative_volume_error"],
            "native initialization failed volume or field checks")

    last_time = 0.0
    step_count = 0
    fields = set()
    final_line = ""
    with log_path.open(encoding="utf-8") as log:
        for line in log:
            line = line.strip()
            if line:
                final_line = line
            if line.startswith("Time = "):
                time = float(line.split("=", 1)[1])
                require(not last_time or fields == {"p", "T"}, "missing pressure or temperature extrema")
                require(math.isfinite(time) and time > last_time, "nonmonotonic native time")
                step_count += 1
                require(step_count < len(samples) and math.isclose(samples[step_count][0], time, rel_tol=1e-9),
                        f"missing probe sample at native time {time:g} s")
                last_time, fields = time, set()
            extrema = HEALTH_LINE.fullmatch(line)
            if last_time and extrema:
                field, maximum, minimum = extrema.groups()
                maximum, minimum = float(maximum), float(minimum)
                require(math.isfinite(maximum) and 0 < minimum <= maximum, f"invalid {field} extrema at {last_time:g} s")
                fields.add(field)
    require(final_line == "End" and fields == {"p", "T"}, "missing normal solver termination or final extrema")
    require(step_count + 1 == len(samples), "extra probe samples outside the native step sequence")
    comparison = binding["comparison"]
    final_step = samples[-1][0] - samples[-2][0]
    require(last_time >= comparison["fixed_candidate_window_s"][1]
            and math.isclose(last_time, comparison["native_end_s"], rel_tol=0, abs_tol=0.5 * final_step + 1e-12),
            "native solver did not reach the prescribed end time")
    return {"job_id": allocation["job_id"], "native_end_s": last_time,
            "run_receipt_sha256": file_digest(run_path), "solver_log_sha256": log_digest,
            "native_initialization_receipt_sha256": initial_digest}


def read_probes(path, radii):
    coordinates = []
    samples = []
    with path.open(encoding="utf-8") as source:
        for line_number, line in enumerate(source, 1):
            line = line.strip()
            if not line:
                continue
            if line.startswith("#"):
                header = PROBE_HEADER.fullmatch(line)
                if header:
                    index, xyz = header.groups()
                    require(not samples and int(index) == len(coordinates), "unexpected native probe index")
                    coordinates.append(tuple(map(float, xyz.split())))
                continue
            time, *pressure = map(float, line.split())
            require(len(pressure) == len(radii) and all(math.isfinite(p) and p > 0 for p in pressure),
                    f"missing or invalid absolute pressure on probe line {line_number}")
            require(math.isfinite(time) and (time > samples[-1][0] if samples else time == 0),
                    f"invalid or nonmonotonic probe time on line {line_number}")
            samples.append((time, pressure))
    require(coordinates == [(0, radius, 0) for radius in radii], "native probe headers do not match fixed wall locations")
    return samples


def fixed_window_peaks(samples, comparison):
    start, end = comparison["fixed_candidate_window_s"]
    require(start == 0 and samples and samples[0][0] == start and samples[-1][0] >= end,
            "probe histories do not span the fixed comparison window")
    stop = next(index for index, (time, _) in enumerate(samples) if time >= end)
    t0, p0 = samples[stop - 1]
    t1, p1 = samples[stop]
    fraction = (end - t0) / (t1 - t0)
    end_pressure = p1 if t1 == end else [a + fraction * (b - a) for a, b in zip(p0, p1)]
    baseline = comparison["pressure_baseline_Pa"]
    for i in range(comparison["required_gauges"]):
        if stop == 1:
            yield None, None
            continue
        time, pressure = max(samples[1:stop], key=lambda row: row[1][i])
        peak = pressure[i]
        if peak > max(baseline, samples[0][1][i], end_pressure[i]):
            yield (peak - baseline) / 1000, time
        else:
            yield None, None


def score(package, folder):
    receipt_path = package / "staging_receipt.json"
    reference_path = package / "peak_reference.json"
    binding = read_json(receipt_path)
    comparison = binding["comparison"]
    require(file_digest(reference_path) == binding["peak_reference_sha256"], "fixed reference hash mismatch")
    reference = read_json(reference_path)
    radii = binding["geometry"]["ground_probe_radii_m"]
    rows = [{"radius_m": row["nominal_radius_m"], "reference_kPa": {
        group: row[f"{group}_kPa"] for group in REFERENCE_GROUPS}, "peak_kPa": None, "peak_time_s": None,
        "APE_percent": {group: None for group in REFERENCE_GROUPS}} for row in reference["rows"]]
    require([row["radius_m"] for row in rows] == radii and len(rows) == comparison["required_gauges"],
            "reference rows do not match the fixed radial gauges")
    require(all(math.isfinite(value) and value >= comparison["minimum_reference_peak_kPa"]
                for row in rows for value in row["reference_kPa"].values()), "reference peak ineligible for MAPE")
    result = {"scene_id": binding["scene_id"], "completed": False, "failures": [], "rows": rows,
              "MAPE_percent": dict.fromkeys(REFERENCE_GROUPS),
              "reference_denominators": comparison["reference_denominators"], "window_s": comparison["fixed_candidate_window_s"],
              "staging_receipt_sha256": file_digest(receipt_path), "reference_sha256": binding["peak_reference_sha256"]}
    try:
        probe_path = folder / "case/postProcessing/groundPressure/0/p"
        result["native_probe_sha256"] = file_digest(probe_path)
        samples = read_probes(probe_path, radii)
        result["native_run"] = check_native_run(folder, receipt_path, binding, samples, result["native_probe_sha256"])
        for row, (peak, time) in zip(rows, fixed_window_peaks(samples, comparison)):
            row["peak_kPa"], row["peak_time_s"] = peak, time
            if peak is None:
                result["failures"].append(f"no positive interior peak at radius {row['radius_m']:g} m")
                continue
            row["APE_percent"] = {group: 100 * abs(peak - value) / value
                                  for group, value in row["reference_kPa"].items()}
    except (OSError, ValueError, KeyError, TypeError) as error:
        result["failures"].append(str(error))
    result["completed"] = not result["failures"]
    if result["completed"]:
        result["MAPE_percent"] = {group: fmean(row["APE_percent"][group] for row in rows)
                                  for group in REFERENCE_GROUPS}
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--run", type=Path, required=True, help="collected native run directory")
    parser.add_argument("--output", type=Path, required=True, help="new JSON output path")
    options = parser.parse_args()
    result = score(options.package, options.run)
    with options.output.open("x", encoding="utf-8") as output:
        json.dump(result, output, indent=2, allow_nan=False)
        output.write("\n")
    return 0 if result["completed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
